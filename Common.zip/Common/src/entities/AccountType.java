package entities;

public enum AccountType {
    PRIVATE,
    BUSINESS;

    // No methods or constructors; simply an enumeration.
}
